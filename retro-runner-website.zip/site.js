(() => {
  'use strict';

  const gameCanvas = document.getElementById('game');
  const captureButton = document.getElementById('capture-button');
  const fullscreenButton = document.getElementById('fullscreen-button');
  const dialog = document.getElementById('share-dialog');
  const preview = document.getElementById('screenshot-preview');
  const status = document.getElementById('share-status');
  let screenshotBlob = null;
  let previewUrl = null;

  function setStatus(message) {
    status.textContent = message;
  }

  function openShareDialog() {
    dialog.hidden = false;
    setStatus('Choose a share destination, or copy the image to paste it into another app.');
    document.getElementById('close-share').focus();
  }

  function closeShareDialog() {
    dialog.hidden = true;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null;
    preview.removeAttribute('src');
    screenshotBlob = null;
    captureButton.focus();
  }

  function captureCanvas() {
    if (!gameCanvas.toBlob) {
      setStatus('Canvas image capture is not supported in this browser.');
      openShareDialog();
      return;
    }

    gameCanvas.toBlob(blob => {
      if (!blob) {
        openShareDialog();
        setStatus('Could not capture the game screen. Try again.');
        return;
      }
      screenshotBlob = blob;
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(blob);
      preview.src = previewUrl;
      openShareDialog();
    }, 'image/png');
  }

  async function shareScreenshot() {
    if (!screenshotBlob) return;
    const file = new File([screenshotBlob], 'retro-runner-screenshot.png', { type: 'image/png' });

    try {
      if (navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
        await navigator.share({
          title: 'Retro Runner screenshot',
          text: 'A screenshot from Retro Runner Arcade.',
          files: [file],
        });
        setStatus('Shared using your device’s share sheet.');
      } else {
        setStatus('Image sharing is not available here. Use COPY SCREENSHOT, then paste it into a sharing app.');
      }
    } catch (error) {
      if (error.name === 'AbortError') setStatus('Share cancelled. The screenshot is still here.');
      else setStatus('Sharing did not complete. You can still copy the screenshot.');
    }
  }

  async function copyScreenshot() {
    if (!screenshotBlob) return;
    try {
      if (!navigator.clipboard || !window.ClipboardItem) throw new Error('Clipboard image support is unavailable.');
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': screenshotBlob })]);
      setStatus('Screenshot copied. Paste it into the app where you want to share it.');
    } catch {
      setStatus('Image copy is not supported in this browser or page context. Use the device share sheet if available.');
    }
  }

  async function copyGameLink() {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setStatus('Game link copied to clipboard.');
    } catch {
      setStatus('Link copy is unavailable here. You can copy the page address from your browser.');
    }
  }

  async function toggleFullscreen() {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      else await document.exitFullscreen();
    } catch {
      setStatus('Fullscreen is unavailable in this browser.');
      dialog.hidden = false;
    }
  }

  captureButton.addEventListener('click', captureCanvas);
  fullscreenButton.addEventListener('click', toggleFullscreen);
  document.getElementById('close-share').addEventListener('click', closeShareDialog);
  document.getElementById('native-share-button').addEventListener('click', shareScreenshot);
  document.getElementById('copy-image-button').addEventListener('click', copyScreenshot);
  document.getElementById('copy-link-button').addEventListener('click', copyGameLink);

  dialog.addEventListener('pointerdown', event => {
    if (event.target === dialog) closeShareDialog();
  });
  window.addEventListener('keydown', event => {
    if (event.code === 'Escape' && !dialog.hidden) closeShareDialog();

    // Discourage ordinary page-save and print shortcuts; this cannot prevent OS screenshots or recording.
    const modifier = event.ctrlKey || event.metaKey;
    if (modifier && ['s', 'p'].includes(event.key.toLowerCase())) event.preventDefault();
  });

  // There are no downloadable media assets; suppress common right-click, drag and selection affordances.
  window.addEventListener('contextmenu', event => event.preventDefault());
  document.addEventListener('dragstart', event => event.preventDefault());
  document.addEventListener('selectstart', event => event.preventDefault());
  document.addEventListener('click', event => {
    const image = event.target.closest && event.target.closest('img');
    if (image) event.preventDefault();
  });
})();
