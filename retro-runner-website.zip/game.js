(() => {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('This browser does not support HTML5 Canvas.');

  const HIGH_SCORE_KEY = 'retro-runner.skin-bests.v1';
  const PIXEL = 4;
  const MAX_SPEED = 650;
  const GRAVITY = 1900;
  const JUMP_VELOCITY = -770;
  const FLAPPY_GRAVITY = 3600;
  const FLAP_VELOCITY = -680;
  const SKIN_IDS = ['classic', 'ninja', 'santa', 'monster', 'spacecat', 'spooky', 'flappy'];
  const DAY_CLASSIC = { bg: '#f7f7f7', ground: '#777777' };

  // Pixel art uses: # main color, + secondary color, o highlight, x dark detail.
  // Everything is drawn from these small text maps; no images or external libraries are used.
  const SKINS = {
    classic: {
      name: 'CLASSIC',
      colors: { bg: '#f7f7f7', ground: '#777777', primary: '#535353', secondary: '#777777', accent: '#f7f7f7', dark: '#303030', pipe: '#3d813b' },
      player: [
        '.......####..', '.......#..##.', '.......####..', '........###..',
        '......#####..', '.....######..', '..#########..', '.##########..',
        '############.', '######.#####.', '##...##..##..', '#####.#####..',
      ],
      ground: ['...#...', '..##...', '.###...', '...####', '...#..#', '...####', '...#...'],
      air: ['..##....', '.####...', '######..', '..##.###', '.##..##.', '##...##.'],
      airLabel: 'BIRD',
    },
    ninja: {
      name: 'NINJA',
      colors: { bg: '#f3d8a5', ground: '#a66d43', primary: '#26313a', secondary: '#e97927', accent: '#ffd45c', dark: '#5a3021', pipe: '#4f8138' },
      player: [
        '.....######...', '....##++++##..', '....#++++++##.', '.....########.',
        '...##########.', '..##++++++++##.', '..############.', '.####++++++####.',
        '#######..######', '######....#####', '#####......####', '#######..######',
      ],
      ground: ['...########...', '..#++++++++#..', '.############.', '.##++++++++##.', '.############.', '..##########..', '...########...'],
      air: ['....#....', '..######.', '.##++++##.', '#########.', '.##++++##.', '..######..', '....#....'],
      airLabel: 'SHURIKEN',
    },
    santa: {
      name: 'SANTA',
      colors: { bg: '#eaf3f7', ground: '#c5d1d5', primary: '#c52d3e', secondary: '#ffffff', accent: '#f3cf69', dark: '#6c2831', pipe: '#44804d' },
      player: [
        '.......####...', '......######..', '.....########.', '.....#++++##..',
        '....##########', '....##++++++##.', '...############', '...##++++++++##',
        '..##############', '..####.####.####', '...##...##...##.', '..####.####.####',
      ],
      ground: ['..########..', '.##++++++++#.', '.############', '.##++++++++##', '.############', '..##########..'],
      air: ['..######..', '.########.', '##########', '.########.', '..######..'],
      airLabel: 'SNOWBALL',
    },
    monster: {
      name: 'MONSTER',
      colors: { bg: '#242b2c', ground: '#69746b', primary: '#536a55', secondary: '#303c34', accent: '#91a96a', dark: '#17211d', pipe: '#5d8f4b' },
      player: [
        '....##..##....', '...########...', '..##++++++##..', '..############',
        '.#############.', '###############', '###############', '.##############',
        '..############.', '..##########...', '.#####..#####..', '#######..######',
      ],
      ground: ['##############', '##++++++++++##', '##++++++++++##', '##++++++++++##', '##############', '##..##..##..##'],
      air: ['...########...', '.############.', '##############', '##++++++++++##', '##############', '..##......##..'],
      airLabel: 'JET',
      shakeOnJump: true,
    },
    spacecat: {
      name: 'SPACE CAT',
      colors: { bg: '#100c1b', ground: '#733d78', primary: '#e99bc6', secondary: '#f6d9f0', accent: '#ff75b8', dark: '#341842', pipe: '#527a58' },
      player: [
        '..##......##..', '..###....###..', '.############.', '##++++++++++##',
        '##############', '##+##++++##+###', '##############', '.############.',
        '..##########..', '...##.##.##....', '..###.##.###...', '..##..##..##....',
      ],
      ground: ['....######....', '..##########..', '.############.', '##############', '##############', '.############.', '..##########..'],
      air: ['..##.....', '.#####...', '########.', '.######..', '...####..', '..##.##..'],
      airLabel: 'METEOR',
      rainbowTrail: true,
    },
    spooky: {
      name: 'SPOOKY',
      colors: { bg: '#21182a', ground: '#765c78', primary: '#e9e0ee', secondary: '#a58bb0', accent: '#ff8a39', dark: '#392341', pipe: '#527c4a' },
      player: [
        '....########....', '..############..', '.##++++++++++##.', '##++++++++++++##',
        '##++++++++++++##', '##++##++++##++##', '##++++++++++++##', '.##++++++++++##.',
        '..############..', '..##.##..##.##...', '.##..##..##..##..', '##...##..##...##.',
      ],
      ground: ['...########...', '.##++++++++##.', '##############', '##++++++++++##', '##############', '.##++++++++##..', '..##########...'],
      air: ['....##....', '..######..', '.##++++##.', '##########', '.##++++##.', '..##..##..'],
      airLabel: 'BAT',
    },
    flappy: {
      name: 'FLAPPY',
      colors: { bg: '#70c5ce', ground: '#ded895', primary: '#f2cf32', secondary: '#fff18a', accent: '#f7f1dc', dark: '#453a2d', pipe: '#58a834' },
      player: [
        '....######....', '..############.', '.##############', '##########+++##',
        '##########+++##', '##########+++##', '.##############', '..##########...',
        '....######.....', '.....####......', '.....##........', '....####.......',
      ],
      playerAlt: [
        '....######....', '..############.', '.##############', '##########+++##',
        '##########+++##', '##########+++##', '.##############', '..##########...',
        '....######.....', '...####.........', '..##............', '####............',
      ],
      ground: ['############', '##++++++++##', '##++++++++##', '##++++++++##', '############'],
      air: ['..##..', '.####.', '######', '######', '.####.'],
      airLabel: 'PIPE',
      flappy: true,
    },
  };

  let width = 0;
  let height = 0;
  let groundY = 0;
  let playerX = 64;
  let state = 'MENU'; // MENU | RUNNING | GAME_OVER
  let selectedIndex = 0;
  let score = 0;
  let bestScores = readBestScores();
  let distance = 0;
  let speed = 350;
  let spawnDistance = 520;
  let groundOffset = 0;
  let lastTime = 0;
  let duckHeld = false;
  let hidden = document.hidden;
  let classicNight = false;
  let obstacles = [];
  let runPhase = 0;
  let trailTimer = 0;
  let trail = [];
  let shakeTime = 0;
  let shakePower = 0;
  let cardBounds = [];
  let pointerDuck = false;
  let playerY = 0;
  let playerVY = 0;
  let onGround = true;

  function readBestScores() {
    try {
      const parsed = JSON.parse(localStorage.getItem(HIGH_SCORE_KEY) || '{}');
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  }

  function saveBestScores() {
    try {
      localStorage.setItem(HIGH_SCORE_KEY, JSON.stringify(bestScores));
    } catch {
      // Some browsers restrict localStorage for files opened with file://.
    }
  }

  function currentSkin() {
    return SKINS[SKIN_IDS[selectedIndex]];
  }

  function bestForCurrentSkin() {
    return Number(bestScores[SKIN_IDS[selectedIndex]]) || 0;
  }

  function spriteSize(sprite) {
    return {
      w: Math.max(...sprite.map(row => row.length)) * PIXEL,
      h: sprite.length * PIXEL,
    };
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    width = Math.max(1, rect.width || window.innerWidth);
    height = Math.max(1, rect.height || window.innerHeight);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;
    groundY = Math.max(145, height - Math.max(48, Math.min(78, height * 0.15)));
    playerX = Math.max(22, Math.min(72, width * 0.1));
    if (onGround) playerY = groundY - spriteSize(currentSkin().player).h;
  }

  function selectSkin(index) {
    selectedIndex = (index + SKIN_IDS.length) % SKIN_IDS.length;
    const skin = currentSkin();
    if (onGround) playerY = groundY - spriteSize(skin.player).h;
  }

  function startGame() {
    const skin = currentSkin();
    state = 'RUNNING';
    score = 0;
    distance = 0;
    speed = skin.flappy ? 245 : 350;
    spawnDistance = width * 0.16;
    groundOffset = 0;
    obstacles = [];
    trail = [];
    trailTimer = 0;
    shakeTime = 0;
    shakePower = 0;
    duckHeld = false;
    pointerDuck = false;
    onGround = !skin.flappy;
    const size = spriteSize(skin.player);
    playerY = skin.flappy ? height * 0.42 : groundY - size.h;
    playerVY = 0;
    classicNight = false;
  }

  function actionPress() {
    const skin = currentSkin();
    if (state === 'MENU' || state === 'GAME_OVER') {
      startGame();
      if (skin.flappy) flap();
      return;
    }
    if (skin.flappy) {
      flap();
    } else if (onGround && !duckHeld) {
      playerVY = JUMP_VELOCITY;
      onGround = false;
      if (skin.shakeOnJump) triggerShake(3.4, 0.12);
    }
  }

  function flap() {
    if (state !== 'RUNNING' || !currentSkin().flappy) return;
    playerVY = FLAP_VELOCITY;
    onGround = false;
  }

  function setDuck(value) {
    if (currentSkin().flappy) return;
    duckHeld = value;
  }

  function endGame() {
    if (state !== 'RUNNING') return;
    state = 'GAME_OVER';
    duckHeld = false;
    pointerDuck = false;
    const id = SKIN_IDS[selectedIndex];
    const finalScore = Math.floor(score);
    if (finalScore > bestForCurrentSkin()) {
      bestScores[id] = finalScore;
      saveBestScores();
    }
  }

  function triggerShake(power, seconds) {
    shakePower = Math.max(shakePower, power);
    shakeTime = Math.max(shakeTime, seconds);
  }

  function spawnRunnerObstacle(skin) {
    if (Math.random() < 0.30 && score >= 35) {
      const type = Math.floor(Math.random() * 3); // low, middle, or high air lane
      const h = 24;
      const playerH = spriteSize(skin.player).h;
      let y;
      if (type === 0) y = groundY - playerH * 0.72; // low: jump over
      else if (type === 1) y = groundY - playerH - 4; // middle: duck under
      else y = groundY - playerH * 1.65; // high: run underneath
      obstacles.push({ type: 'air', lane: type, x: width + 24, y, w: 48, h, phase: 0 });
    } else {
      const size = spriteSize(skin.ground);
      const scale = 0.82 + Math.random() * 0.22;
      obstacles.push({
        type: 'ground',
        x: width + 24,
        y: groundY - size.h * scale,
        w: size.w * scale,
        h: size.h * scale,
        scale,
      });
    }
    spawnDistance = 420 + Math.random() * 260;
  }

  function spawnPipePair() {
    const gapSize = Math.min(156, Math.max(112, groundY - 70));
    const margin = gapSize * 0.5 + 34;
    const minCenter = Math.min(margin, groundY * 0.5);
    const maxCenter = Math.max(minCenter + 8, groundY - margin);
    const center = minCenter + Math.random() * Math.max(1, maxCenter - minCenter);
    obstacles.push({
      type: 'pipe',
      x: width + 32,
      w: 62,
      gapTop: center - gapSize / 2,
      gapBottom: center + gapSize / 2,
      passed: false,
    });
    spawnDistance = 245 + Math.random() * 90;
    speed = Math.min(410, speed + 2);
  }

  function update(dt) {
    if (state !== 'RUNNING') {
      if (shakeTime > 0) shakeTime = Math.max(0, shakeTime - dt);
      return;
    }

    const skin = currentSkin();
    if (skin.flappy) updateFlappy(dt, skin);
    else updateRunner(dt, skin);

    if (shakeTime > 0) shakeTime = Math.max(0, shakeTime - dt);
  }

  function updateRunner(dt, skin) {
    speed = Math.min(MAX_SPEED, 350 + distance * 0.075);
    distance += speed * dt;
    score = Math.floor(distance / 9);
    classicNight = skin.name === 'CLASSIC' && Math.floor(score / 700) % 2 === 1;
    groundOffset = (groundOffset + speed * dt) % 36;
    runPhase += dt * speed * 0.04;

    const wasAirborne = !onGround;
    if (!onGround) {
      const gravity = GRAVITY * (skin.gravityMultiplier || 1);
      playerVY += gravity * dt;
      if (duckHeld) playerVY = Math.min(1080, playerVY + 1350 * dt);
      playerY += playerVY * dt;
      const floor = groundY - spriteSize(skin.player).h;
      if (playerY >= floor) {
        playerY = floor;
        playerVY = 0;
        onGround = true;
        if (wasAirborne && skin.shakeOnJump) triggerShake(3.4, 0.12);
      }
    }

    if (skin.rainbowTrail) {
      trailTimer += dt;
      if (trailTimer >= 0.035) {
        trailTimer = 0;
        trail.unshift(playerY + spriteSize(skin.player).h * 0.58);
        if (trail.length > 18) trail.pop();
      }
    }

    spawnDistance -= speed * dt;
    if (spawnDistance <= 0) spawnRunnerObstacle(skin);
    for (const obstacle of obstacles) {
      obstacle.x -= speed * dt;
      if (obstacle.type === 'air') obstacle.phase += dt * 10;
    }
    obstacles = obstacles.filter(obstacle => obstacle.x + obstacle.w > -30);

    const player = runnerPlayerBox(skin);
    for (const obstacle of obstacles) {
      if (runnerCollision(player, obstacle, skin)) {
        endGame();
        return;
      }
    }
  }

  function updateFlappy(dt, skin) {
    distance += speed * dt;
    playerVY += FLAPPY_GRAVITY * (skin.gravityMultiplier || 1) * dt;
    playerY += playerVY * dt;
    runPhase += dt * 18;

    spawnDistance -= speed * dt;
    if (spawnDistance <= 0) spawnPipePair();
    for (const pipe of obstacles) pipe.x -= speed * dt;
    obstacles = obstacles.filter(pipe => pipe.x + pipe.w > -20);

    const size = spriteSize(skin.player);
    const player = { x: playerX + 5, y: playerY + 4, w: size.w - 10, h: size.h - 8 };
    if (playerY < 0 || playerY + size.h >= groundY) {
      endGame();
      return;
    }

    for (const pipe of obstacles) {
      const horizontallyOverlapping = player.x < pipe.x + pipe.w && player.x + player.w > pipe.x;
      if (horizontallyOverlapping && (player.y < pipe.gapTop || player.y + player.h > pipe.gapBottom)) {
        endGame();
        return;
      }
      if (!pipe.passed && pipe.x + pipe.w < playerX) {
        pipe.passed = true;
        score += 1;
      }
    }
  }

  function runnerPlayerBox(skin) {
    const size = spriteSize(skin.player);
    const ducking = duckHeld && onGround;
    const h = ducking ? size.h * 0.58 : size.h;
    const w = size.w * (ducking ? 0.93 : 0.82);
    return {
      x: playerX + size.w * 0.08,
      y: (ducking ? groundY - h : playerY) + size.h * (ducking ? 0.10 : 0.06),
      w,
      h: h * 0.84,
    };
  }

  function runnerCollision(player, obstacle, skin) {
    if (obstacle.type === 'air') {
      const box = { x: obstacle.x + 5, y: obstacle.y + 3, w: obstacle.w - 10, h: obstacle.h - 6 };
      return intersects(player, box);
    }
    const box = {
      x: obstacle.x + obstacle.w * 0.12,
      y: obstacle.y + obstacle.h * 0.08,
      w: obstacle.w * 0.76,
      h: obstacle.h * 0.9,
    };
    return intersects(player, box);
  }

  function intersects(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function draw() {
    const skin = currentSkin();
    const palette = activePalette(skin);
    ctx.save();
    if (skin.shakeOnJump && shakeTime > 0) {
      const strength = shakePower * (shakeTime / 0.12);
      ctx.translate((Math.random() - 0.5) * strength, (Math.random() - 0.5) * strength);
    }
    ctx.fillStyle = palette.bg;
    ctx.fillRect(-4, -4, width + 8, height + 8);
    drawGround(skin, palette);
    if (skin.rainbowTrail && state === 'RUNNING') drawRainbowTrail(skin);
    if (skin.flappy) {
      for (const pipe of obstacles) drawPipe(pipe, skin);
    } else {
      for (const obstacle of obstacles) drawRunnerObstacle(obstacle, skin, palette);
    }
    drawPlayer(skin, palette);
    drawScore(palette);
    if (state === 'MENU') drawMenu(skin, palette);
    if (state === 'GAME_OVER') drawGameOver(skin, palette);
    ctx.restore();
  }

  function activePalette(skin) {
    if (skin.name === 'CLASSIC' && classicNight) {
      return { ...skin.colors, bg: '#202124', ground: '#d4d6d8', primary: '#f1f3f4', secondary: '#d4d6d8', accent: '#202124', dark: '#202124' };
    }
    return skin.colors;
  }

  function drawGround(skin, palette) {
    if (skin.flappy) {
      ctx.fillStyle = palette.ground;
      ctx.fillRect(0, groundY, width, height - groundY);
      ctx.fillStyle = '#c4b76d';
      ctx.fillRect(0, groundY, width, 6);
      return;
    }
    ctx.strokeStyle = palette.ground;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, groundY + 1);
    ctx.lineTo(width, groundY + 1);
    ctx.stroke();
    ctx.fillStyle = palette.ground;
    for (let x = -groundOffset; x < width; x += 36) {
      ctx.fillRect(x, groundY + 12, 14, 2);
      if (Math.floor((x + groundOffset) / 36) % 3 === 0) ctx.fillRect(x + 23, groundY + 23, 5, 2);
    }
  }

  function drawScore(palette) {
    ctx.fillStyle = palette.primary;
    ctx.font = `${Math.max(13, Math.min(18, width * 0.019))}px "Courier New", monospace`;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'top';
    ctx.fillText(`HI ${formatScore(bestForCurrentSkin())}  ${formatScore(score)}`, width - 22, 18);
  }

  function drawMenu(skin, palette) {
    drawCenteredText('SELECT SKIN: 1 TO 7', palette.primary, height * 0.19, 19, true);
    drawCenteredText(`${skin.name} SELECTED`, palette.primary, height * 0.25, 13, true);
    cardBounds = layoutCards();
    cardBounds.forEach((card, index) => {
      const active = index === selectedIndex;
      ctx.fillStyle = active ? palette.primary : palette.bg;
      ctx.strokeStyle = palette.primary;
      ctx.lineWidth = active ? 2 : 1;
      ctx.fillRect(card.x, card.y, card.w, card.h);
      ctx.strokeRect(card.x + 0.5, card.y + 0.5, card.w - 1, card.h - 1);
      drawPixelArt(SKINS[SKIN_IDS[index]].player, card.x + 7, card.y + 9, 1.45, SKINS[SKIN_IDS[index]].colors);
      ctx.fillStyle = active ? palette.bg : palette.primary;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.font = `bold ${Math.max(8, Math.min(11, card.w * 0.13))}px "Courier New", monospace`;
      ctx.fillText(`${index + 1} ${shortName(SKINS[SKIN_IDS[index]].name, card.w < 88)}`, card.x + 28, card.y + card.h / 2);
    });
    drawCenteredText('PRESS SPACE OR TAP TO START', palette.primary, height * 0.48, Math.min(15, width * 0.047), true);
    drawCenteredText(skin.flappy ? 'SPACE / TOP TAP TO FLAP' : '↑ JUMP  ·  HOLD ↓ / BOTTOM TO DUCK', palette.primary, height * 0.55, 11, false);
  }

  function layoutCards() {
    const cols = 4;
    const gap = 7;
    const margin = Math.min(22, width * 0.06);
    const cardW = Math.max(52, Math.min(136, (width - margin * 2 - gap * (cols - 1)) / cols));
    const cardH = Math.max(28, Math.min(54, height * 0.085));
    const rowGap = 8;
    const firstY = Math.max(42, Math.min(height * 0.24, height - cardH * 2 - 90));
    const fullW = cols * cardW + (cols - 1) * gap;
    const startX = (width - fullW) / 2;
    return SKIN_IDS.map((_, index) => {
      const row = index < cols ? 0 : 1;
      const col = row === 0 ? index : index - cols;
      const rowCount = row === 0 ? cols : SKIN_IDS.length - cols;
      const rowW = rowCount * cardW + (rowCount - 1) * gap;
      const rowX = (width - rowW) / 2;
      return { x: row === 0 ? startX + col * (cardW + gap) : rowX + col * (cardW + gap), y: firstY + row * (cardH + rowGap), w: cardW, h: cardH };
    });
  }

  function drawGameOver(skin, palette) {
    drawCenteredText('GAME OVER', palette.primary, height * 0.43, 24, true);
    drawCenteredText('PRESS SPACE TO RESTART', palette.primary, height * 0.43 + 34, 15, true);
    drawCenteredText(`${skin.name}  ·  SCORE ${formatScore(score)}`, palette.primary, height * 0.43 + 63, 12, false);
  }

  function drawCenteredText(text, color, y, size, bold) {
    ctx.fillStyle = color;
    ctx.font = `${bold ? 'bold ' : ''}${size}px "Courier New", monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, width / 2, y);
  }

  function drawPlayer(skin, palette) {
    const sprite = skin.flappy && Math.floor(runPhase) % 2 ? (skin.playerAlt || skin.player) : skin.player;
    const size = spriteSize(sprite);
    const ducking = duckHeld && onGround && state === 'RUNNING' && !skin.flappy;
    const drawH = ducking ? size.h * 0.58 : size.h;
    const drawY = ducking ? groundY - drawH : playerY;
    drawPixelArt(sprite, playerX, drawY, PIXEL, palette, 1, ducking ? 0.58 : 1);
  }

  function drawPixelArt(rows, x, y, scale, colors, scaleX = 1, scaleY = 1) {
    const map = { '#': colors.primary, '+': colors.secondary, 'o': colors.accent, 'x': colors.dark };
    rows.forEach((row, r) => {
      for (let c = 0; c < row.length; c += 1) {
        const color = map[row[c]];
        if (!color) continue;
        ctx.fillStyle = color;
        ctx.fillRect(x + c * scale * scaleX, y + r * scale * scaleY, scale * scaleX, scale * scaleY);
      }
    });
  }

  function drawRunnerObstacle(obstacle, skin, palette) {
    if (obstacle.type === 'ground') {
      drawPixelArt(skin.ground, obstacle.x, obstacle.y, PIXEL * obstacle.scale, palette);
      return;
    }
    const sprite = skin.air;
    const size = spriteSize(sprite);
    const scaleX = obstacle.w / size.w;
    const scaleY = obstacle.h / size.h;
    const bob = Math.sin(obstacle.phase) * (obstacle.lane === 1 ? 1.5 : 0.4);
    drawPixelArt(sprite, obstacle.x, obstacle.y + bob, PIXEL, palette, scaleX, scaleY);
  }

  function drawPipe(pipe, skin) {
    const color = skin.colors.pipe;
    const capH = 16;
    ctx.fillStyle = color;
    ctx.fillRect(pipe.x + 5, 0, pipe.w - 10, pipe.gapTop);
    ctx.fillRect(pipe.x, pipe.gapTop - capH, pipe.w, capH);
    ctx.fillRect(pipe.x + 5, pipe.gapBottom, pipe.w - 10, groundY - pipe.gapBottom);
    ctx.fillRect(pipe.x, pipe.gapBottom, pipe.w, capH);
    ctx.fillStyle = skin.colors.secondary;
    ctx.fillRect(pipe.x + 8, 0, 5, Math.max(0, pipe.gapTop - capH));
    ctx.fillRect(pipe.x + 8, pipe.gapBottom + capH, 5, Math.max(0, groundY - pipe.gapBottom - capH));
  }

  function drawRainbowTrail() {
    const colors = ['#ff4d6d', '#ff9f43', '#ffe66d', '#5dd39e', '#4dabf7', '#9775fa'];
    trail.forEach((sampleY, index) => {
      const alpha = Math.max(0.05, 0.68 * (1 - index / trail.length));
      ctx.globalAlpha = alpha;
      ctx.fillStyle = colors[index % colors.length];
      ctx.fillRect(playerX - 7 - index * 3, sampleY + (index % 2) * 3, 8, 5);
    });
    ctx.globalAlpha = 1;
  }

  function shortName(name, compact) {
    if (!compact) return name;
    return { CLASSIC: 'CLS', NINJA: 'NIN', SANTA: 'SAN', MONSTER: 'MON', 'SPACE CAT': 'CAT', SPOOKY: 'SPOOK', FLAPPY: 'FLAP' }[name] || name;
  }

  function formatScore(value) {
    return String(Math.max(0, Math.floor(value))).padStart(5, '0');
  }

  function pointerPosition(event) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (width / rect.width),
      y: (event.clientY - rect.top) * (height / rect.height),
    };
  }

  function onPointerDown(event) {
    event.preventDefault();
    const point = pointerPosition(event);
    if (state === 'MENU') {
      const hit = cardBounds.findIndex(card => point.x >= card.x && point.x <= card.x + card.w && point.y >= card.y && point.y <= card.y + card.h);
      if (hit >= 0) {
        selectSkin(hit);
        return;
      }
    }
    if (point.y < height * 0.5) {
      actionPress();
    } else if (state === 'RUNNING' && !currentSkin().flappy) {
      pointerDuck = true;
      duckHeld = true;
      canvas.setPointerCapture?.(event.pointerId);
    }
  }

  function releaseDuck() {
    pointerDuck = false;
    duckHeld = false;
  }

  function frame(now) {
    if (!lastTime) lastTime = now;
    const dt = Math.min((now - lastTime) / 1000, 0.04);
    lastTime = now;
    if (!hidden) update(dt);
    draw();
    requestAnimationFrame(frame);
  }

  window.addEventListener('keydown', event => {
    if (/^Digit[1-7]$/.test(event.code) || /^[1-7]$/.test(event.key)) {
      if (state === 'MENU') {
        const number = Number(event.key || event.code.slice(-1));
        selectSkin(number - 1);
      }
      return;
    }
    if (event.code === 'Space' || event.code === 'ArrowUp') {
      event.preventDefault();
      if (!event.repeat) actionPress();
    }
    if (event.code === 'ArrowDown') {
      event.preventDefault();
      if (state === 'RUNNING' && !currentSkin().flappy) setDuck(true);
    }
  });

  window.addEventListener('keyup', event => {
    if (event.code === 'ArrowDown') setDuck(false);
  });
  window.addEventListener('blur', releaseDuck);
  window.addEventListener('pointerup', releaseDuck);
  window.addEventListener('pointercancel', releaseDuck);
  document.addEventListener('visibilitychange', () => {
    hidden = document.hidden;
    lastTime = 0;
    releaseDuck();
  });
  window.addEventListener('resize', resize, { passive: true });
  canvas.addEventListener('pointerdown', onPointerDown);

  resize();
  requestAnimationFrame(frame);
})();
